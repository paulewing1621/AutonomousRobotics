#include <vector>
#include <string>
#include <map>
#include <list>
#include <chrono>
#include <functional>
#include <rclcpp/rclcpp.hpp>
#include <tf2/utils.h>
#include <tf2_ros/transform_listener.h>
#include <tf2_ros/buffer.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <nav_msgs/msg/occupancy_grid.hpp>
#include <nav_msgs/msg/path.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#define FREE 0xFF
#define UNKNOWN 0x80
#define OCCUPIED 0x00
#define WIN_SIZE 800
using std::placeholders::_1;
using namespace std::chrono_literals;

class OccupancyGridPlanner : public rclcpp::Node {
    protected:
        rclcpp::Subscription<nav_msgs::msg::OccupancyGrid>::SharedPtr og_sub_;
        rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr target_sub_;
        rclcpp::Publisher<nav_msgs::msg::Path>::SharedPtr path_pub_;
        rclcpp::TimerBase::SharedPtr timer_;
        rclcpp::TimerBase::SharedPtr exploration_timer_; 
        std::shared_ptr<tf2_ros::TransformListener> tf_listener{nullptr};
        std::unique_ptr<tf2_ros::Buffer> tf_buffer;
        cv::Rect roi_;
        cv::Mat_<uint8_t> og_, cropped_og_;
        cv::Mat_<cv::Vec3b> og_rgb_, og_rgb_marked_;
        cv::Point og_center_;
        nav_msgs::msg::MapMetaData info_;
        std::string frame_id_;
        std::string base_link_;
        bool headless_;
        bool ready_;
        bool debug_;
        double robot_radius_;
        typedef std::multimap<float, cv::Point3i> Heap;
        cv::Point P2(const cv::Point3i & P) {return cv::Point(P.x,P.y);}
        std::vector<cv::Point> detectFrontiers() {
        std::vector<cv::Point> frontiers;
        const std::array<cv::Point, 4> neighbours4 = {
            cv::Point( 0, -1),   // haut
            cv::Point( 0,  1),   // bas
            cv::Point(-1,  0),   // gauche
            cv::Point( 1,  0)    // droite
        };
        for (int row = 0; row < (int)info_.height; row++) {
            for (int col = 0; col < (int)info_.width; col++) {
                if (og_(row, col) != FREE) continue;
                bool has_unknown_neighbour = false;
                for (const cv::Point& offset : neighbours4) {
                    cv::Point neighbour(col + offset.x, row + offset.y);
                    if (!isInGrid(neighbour)) continue;
                    if (og_(neighbour.y, neighbour.x) == UNKNOWN) {
                        has_unknown_neighbour = true;
                        break;
                    }
                }
                if (has_unknown_neighbour) {
                    frontiers.push_back(cv::Point(col, row));
                }
            }
        }
        RCLCPP_INFO(this->get_logger(), "Detected %zu frontier points", frontiers.size());
        return frontiers;
    }
        cv::Point selectBestFrontier(
        const std::vector<cv::Point>& frontiers,
        const cv::Point& start,
        int unknown_radius = 10,
        double alpha = 1.0)
    {
        if (frontiers.empty()) {
            RCLCPP_INFO(this->get_logger(), "No frontier found, exploration complete.");
            return cv::Point(-1, -1);
        }
        cv::Point best_point(-1, -1);
        double best_score = -std::numeric_limits<double>::infinity();
        for (const cv::Point& P : frontiers) {
            int gain = 0;
            for (int dr = -unknown_radius; dr <= unknown_radius; dr++) {
                for (int dc = -unknown_radius; dc <= unknown_radius; dc++) {
                    cv::Point neighbour(P.x + dc, P.y + dr);
                    if (!isInGrid(neighbour)) continue;
                    if (og_(neighbour.y, neighbour.x) == UNKNOWN) {
                        gain++;
                    }
                }
            }
            double dist = std::hypot(P.x - start.x, P.y - start.y);
            double score = alpha * gain - dist;
            RCLCPP_DEBUG(this->get_logger(),
                "Frontier (%d, %d) : gain=%d  dist=%.1f  score=%.2f",
                P.x, P.y, gain, dist, score);
            if (score > best_score) {
                best_score = score;
                best_point = P;
            }
        }
        RCLCPP_INFO(this->get_logger(),
            "Best frontier: (%d, %d) with score %.2f",
            best_point.x, best_point.y, best_score);

        return best_point;
    }
    void explorationStep(){
        if (!ready_) return;
        geometry_msgs::msg::TransformStamped tf;
        try {
            tf = tf_buffer->lookupTransform(frame_id_, base_link_, tf2::TimePointZero);
        } catch (const tf2::TransformException & ex) {
            RCLCPP_WARN(this->get_logger(), "%s", ex.what());
            return;
        }
        double s_yaw = tf2::getYaw(tf.transform.rotation);
        int s_theta = (int(std::round(s_yaw / (M_PI / 4.0))) % 8 + 8) % 8;
        cv::Point3i start = cv::Point3i(
            tf.transform.translation.x / info_.resolution + og_center_.x,
            tf.transform.translation.y / info_.resolution + og_center_.y,
            s_theta);
        std::vector<cv::Point> frontiers = detectFrontiers();
        if (frontiers.empty()) {
            RCLCPP_INFO(this->get_logger(), "Exploration complete.");
            exploration_timer_->cancel();
            return;
        }
        cv::Point best = selectBestFrontier(frontiers, cv::Point(start.x, start.y));
        if (best.x == -1) return;
        planToPixelTarget(start, cv::Point3i(best.x, best.y, 0));
        }
        void og_callback(nav_msgs::msg::OccupancyGrid::SharedPtr msg) {
            info_ = msg->info;
            frame_id_ = msg->header.frame_id;
            og_ = cv::Mat_<uint8_t>(msg->info.height, msg->info.width,0xFF);
            og_center_ = cv::Point(-info_.origin.position.x/info_.resolution,
                    -info_.origin.position.y/info_.resolution);
            unsigned int maxx=0, minx=msg->info.width, 
                         maxy=0, miny=msg->info.height;
            for (unsigned int j=0;j<msg->info.height;j++) {
                for (unsigned int i=0;i<msg->info.width;i++) {
                    int8_t v = msg->data[j*msg->info.width + i];
                    switch (v) {
                        case 0: 
                            og_(j,i) = FREE; 
                            break;
                        case 100: 
                            og_(j,i) = OCCUPIED; 
                            break;
                        case -1: 
                        default:
                            og_(j,i) = UNKNOWN; 
                            break;
                    }
                    if (og_(j,i) != UNKNOWN) {
                        minx = std::min(minx,i);
                        miny = std::min(miny,j);
                        maxx = std::max(maxx,i);
                        maxy = std::max(maxy,j);
                    }
                }
            }
            int expansion_size = std::ceil(robot_radius_ / info_.resolution);
            cv::Mat element = cv::getStructuringElement(
                cv::MORPH_ELLIPSE,
                cv::Size(2*expansion_size +1,2 * expansion_size + 1),
                cv::Point(expansion_size,expansion_size)
            );
            cv::Mat unknown_mask = (og_ == UNKNOWN);
            cv::Mat expanded_og;
            cv::erode(og_, expanded_og, element);
            expanded_og.setTo(UNKNOWN, unknown_mask);
            og_ = expanded_og;
            if (!ready_) {
                ready_ = true;
                RCLCPP_INFO(this->get_logger(),"Received occupancy grid, ready_ to plan");
            }
            unsigned int w = maxx - minx;
            unsigned int h = maxy - miny;
            roi_ = cv::Rect(minx,miny,w,h);
            if (!headless_) {
                cv::cvtColor(og_, og_rgb_, cv::COLOR_GRAY2RGB);
                cropped_og_ = cv::Mat_<uint8_t>(og_,roi_);
                if ((w > WIN_SIZE) || (h > WIN_SIZE)) {
                    double ratio = w / ((double)h);
                    cv::Size new_size;
                    if (ratio >= 1) {
                        new_size = cv::Size(WIN_SIZE,WIN_SIZE/ratio);
                    } else {
                        new_size = cv::Size(WIN_SIZE*ratio,WIN_SIZE);
                    }
                    cv::Mat_<uint8_t> resized_og;
                    cv::resize(cropped_og_,resized_og,new_size);
                    cv::imshow( "OccGrid", resized_og );
                } else {
                    cv::imshow( "OccGrid", og_rgb_ );
                }
            }
        }
        bool isInGrid(const cv::Point & P) {
            if ((P.x < 0) || (P.x >= (signed)info_.width) 
                    || (P.y < 0) || (P.y >= (signed)info_.height)) {
                return false;
            }
            return true;
        }
        void target_callback(geometry_msgs::msg::PoseStamped::SharedPtr msg) {
            geometry_msgs::msg::TransformStamped transformStamped;
            geometry_msgs::msg::PoseStamped pose;
            if (!ready_) {
                RCLCPP_WARN(this->get_logger(),"Ignoring target while the occupancy grid has not been received");
                return;
            }
            RCLCPP_INFO(this->get_logger(),"Received planning request in frame %s (base link %s, frame id %s)",
                    msg->header.frame_id.c_str(),
                    base_link_.c_str(),
                    frame_id_.c_str());
            og_rgb_marked_ = og_rgb_.clone();
            if (debug_) {
                pose = *msg;
            } else {
                try{
                    std::string errStr;
                    if (!tf_buffer->canTransform(frame_id_, msg->header.frame_id, msg->header.stamp,
                                rclcpp::Duration(std::chrono::duration<double>(1.0)),&errStr)) {
                        RCLCPP_ERROR(this->get_logger(),"Cannot transform target: %s",errStr.c_str());
                        return;
                    }
                    transformStamped = tf_buffer->lookupTransform(frame_id_, msg->header.frame_id, msg->header.stamp);
                    tf2::doTransform(*msg,pose,transformStamped);
                    if (!tf_buffer->canTransform(frame_id_, base_link_, msg->header.stamp,
                                rclcpp::Duration(std::chrono::duration<double>(1.0)),&errStr)) {
                        RCLCPP_ERROR(this->get_logger(),"Cannot transform base_link: %s",errStr.c_str());
                        return;
                    }
                    transformStamped = tf_buffer->lookupTransform(frame_id_, base_link_, tf2::TimePointZero);
                }
                catch (const tf2::TransformException & ex){
                    RCLCPP_ERROR(this->get_logger(),"%s",ex.what());
                }
            }
            double t_yaw = tf2::getYaw(pose.pose.orientation);
            int t_theta= (int(std::round(t_yaw/(M_PI/4.0)))%8 +8)%8;
            cv::Point3i target = cv::Point3i(pose.pose.position.x / info_.resolution, 
                    pose.pose.position.y / info_.resolution, t_theta)
                + cv::Point3i(og_center_.x, og_center_.y, 0);
            RCLCPP_INFO(this->get_logger(),"Planning target: %.2f %.2f %.2f-> %d %d",
                    pose.pose.position.x, pose.pose.position.y, t_yaw, target.x, target.y);
            cv::circle(og_rgb_marked_,P2(target), 10, cv::Scalar(0,0,255));
            if (!headless_) {
                cv::imshow( "OccGrid", og_rgb_marked_ );
            }
            if (!isInGrid(P2(target))) {
                RCLCPP_ERROR(this->get_logger(),"Invalid target point (%.2f %.2f) -> (%d %d)",
                        pose.pose.position.x, pose.pose.position.y, target.x, target.y);
                return;
            }
            if (og_(P2(target)) == OCCUPIED ) {
                RCLCPP_ERROR(this->get_logger(),"Invalid target point: occupancy = %d",og_(P2(target)));
                return;
            }
            cv::Point3i start;
            double s_yaw = 0;
            if (debug_) {
                start = cv::Point3i(og_center_.x, og_center_.y, 0);
            } else {
                s_yaw = tf2::getYaw(transformStamped.transform.rotation);
                int s_theta = (int(std::round(s_yaw / (M_PI / 4.0))) % 8 + 8) % 8;
                start = cv::Point3i(transformStamped.transform.translation.x / info_.resolution, 
                                    transformStamped.transform.translation.y / info_.resolution, s_theta)
                      + cv::Point3i(og_center_.x, og_center_.y, 0);
            }
            RCLCPP_INFO(this->get_logger(),"Planning origin %.2f %.2f %.2f -> %d %d",
                    transformStamped.transform.translation.x, transformStamped.transform.translation.y,
                    s_yaw, start.x, start.y);
            cv::circle(og_rgb_marked_, P2(start), 10, cv::Scalar(0,255,0));
            if (!headless_) {
                cv::imshow( "OccGrid", og_rgb_marked_ );
            }
            if (!isInGrid(P2(start))) {
                RCLCPP_ERROR(this->get_logger(),"Invalid starting point (%.2f %.2f) -> (%d %d)",
                        transformStamped.transform.translation.x, transformStamped.transform.translation.y,
                        start.x, start.y);
                return;
            }
            if (og_(P2(start)) == OCCUPIED) {
                RCLCPP_ERROR(this->get_logger(),"Invalid start point: occupancy = %d",og_(P2(start)));
                return;
            }
            RCLCPP_INFO(this->get_logger(),"Starting planning from (%d, %d) to (%d, %d)",start.x,start.y, target.x, target.y);
            planToPixelTarget(start, target);
        }
        void planToPixelTarget(cv::Point3i start, cv::Point3i target) {
            int dims[3] = {og_.size().width, og_.size().height, 8};
            cv::Mat_<float> cell_value(3,dims, NAN);
            cv::Mat_<cv::Vec3s> predecessor(3,dims);
            std::array<std::array<cv::Point3i, 3>, 8> neighbours = {{
                {cv::Point3i(1, 0, 0), cv::Point3i(0, 0, 1), cv::Point3i(0, 0, -1)},   // k=0
                {cv::Point3i(1, 1, 0), cv::Point3i(0, 0, 1), cv::Point3i(0, 0, -1)},   // k=1
                {cv::Point3i(0, 1, 0), cv::Point3i(0, 0, 1), cv::Point3i(0, 0, -1)},   // k=2
                {cv::Point3i(-1, 1, 0), cv::Point3i(0, 0, 1), cv::Point3i(0, 0, -1)},  // k=3
                {cv::Point3i(-1, 0, 0), cv::Point3i(0, 0, 1), cv::Point3i(0, 0, -1)},  // k=4
                {cv::Point3i(-1, -1, 0), cv::Point3i(0, 0, 1), cv::Point3i(0, 0, -1)}, // k=5
                {cv::Point3i(0, -1, 0), cv::Point3i(0, 0, 1), cv::Point3i(0, 0, -1)},  // k=6
                {cv::Point3i(1, -1, 0), cv::Point3i(0, 0, 1), cv::Point3i(0, 0, -1)}   // k=7
            }};
            std::array<std::array<float, 3>, 8> cost= {{
                {1.0, 0.5, 0.5},          
                {sqrt(2.0), 0.5, 0.5},    
                {1.0, 0.5, 0.5},         
                {sqrt(2.0), 0.5, 0.5},    
                {1.0, 0.5, 0.5},          
                {sqrt(2.0), 0.5, 0.5},    
                {1.0, 0.5, 0.5},          
                {sqrt(2.0), 0.5, 0.5}     
            }};
            auto heuristic =[](cv::Point3i p1, cv::Point3i p2){
                float dist=std::hypot(p1.x - p2.x,p1.y -p2.y);
                int d_theta = std::abs(p1.z - p2.z);
                d_theta = std::min(d_theta, 8 - d_theta);
                return dist + (d_theta * 0.5); 
            };
            Heap heap;
            float epsilon = 1.0;
            heap.insert(Heap::value_type(epsilon * heuristic(start,target), start));
            cell_value.at<float>(start.x, start.y, start.z) = 0;
            while (!heap.empty()) {
                Heap::iterator hit = heap.begin();
                cv::Point3i this_cell = hit->second;
               float this_cost = cell_value.at<float>(this_cell.x, this_cell.y, this_cell.z);
                heap.erase(hit);
                if (this_cell == target){
                    break;
                }
                for (size_t i=0;i<3;i++) {
                    cv::Point3i dest = this_cell + neighbours[this_cell.z][i];
                    dest.z = (dest.z + 8) % 8;
                    if (!isInGrid(P2(dest))) {
                        continue;
                    }
                    uint8_t og = og_(P2(dest));
                    if (og == OCCUPIED) {
                        continue;
                    }
                    float cv_val = cell_value.at<float>(dest.x, dest.y, dest.z);
                    float new_cost = this_cost + cost[this_cell.z][i]; 
                    if (std::isnan(cv_val) || (new_cost < cv_val)) {
                        predecessor.at<cv::Vec3s>(dest.x, dest.y, dest.z) = cv::Vec3s(this_cell.x, this_cell.y, this_cell.z);
                        cell_value.at<float>(dest.x, dest.y, dest.z) = new_cost;
                        float f_cost = new_cost + (epsilon * heuristic(dest, target));
                        heap.insert(Heap::value_type(f_cost, dest));
                    }
                }
            }
            if (std::isnan(cell_value.at<float>(target.x, target.y, target.z))) {
                RCLCPP_ERROR(this->get_logger(),"No path found from (%d, %d, th:%d) to (%d, %d, th:%d)",
                        start.x, start.y, start.z, target.x, target.y, target.z);
                return;
            }
            RCLCPP_INFO(this->get_logger(),"Planning completed");
            std::list<cv::Point3i> lpath;
            while (target != start) {
                assert(lpath.size()<1000000);
                lpath.push_front(target);
                cv::Vec3s p = predecessor.at<cv::Vec3s>(target.x, target.y, target.z);
                target.x = p[0]; target.y = p[1]; target.z = p[2];
            }
            lpath.push_front(start);
            nav_msgs::msg::Path path;
            path.header.stamp = this->get_clock()->now();
            path.header.frame_id = frame_id_;
            path.poses.resize(lpath.size());
            std::list<cv::Point3i>::const_iterator it = lpath.begin();
            unsigned int ipose = 0;
            while (it != lpath.end()) {
                path.poses[ipose].header = path.header;
                cv::Point P = P2(*it) - og_center_;
                path.poses[ipose].pose.position.x = (P.x) * info_.resolution;
                path.poses[ipose].pose.position.y = (P.y) * info_.resolution;
                tf2::Quaternion Q;
                Q.setRPY(0, 0, it->z * (M_PI / 4.0)); 
                path.poses[ipose].pose.orientation = tf2::toMsg(Q);
                ipose++;
                it ++;
            }
            path_pub_->publish(path);
            RCLCPP_INFO(this->get_logger(),"Request completed");
        }

    public:
        OccupancyGridPlanner() : rclcpp::Node("occgrid_planner") {
            ready_ = false;
            this->declare_parameter("~/base_frame",std::string("body"));
            this->declare_parameter("~/debug",false);
            this->declare_parameter("~/headless",true);
            this->declare_parameter("~/robot_radius",0.1);
            base_link_ = this->get_parameter("~/base_frame").as_string();
            debug_ = this->get_parameter("~/debug").as_bool();
            headless_ = this->get_parameter("~/headless").as_bool();
            robot_radius_ = this->get_parameter("~/robot_radius").as_double();
            tf_buffer = std::make_unique<tf2_ros::Buffer>(this->get_clock());
            tf_listener = std::make_shared<tf2_ros::TransformListener>(*tf_buffer);
            og_sub_ = this->create_subscription<nav_msgs::msg::OccupancyGrid>("~/occ_grid",1,
                    std::bind(&OccupancyGridPlanner::og_callback,this,std::placeholders::_1));
            target_sub_ = this->create_subscription<geometry_msgs::msg::PoseStamped>("~/goal",1,
                    std::bind(&OccupancyGridPlanner::target_callback,this,std::placeholders::_1));
            path_pub_ = this->create_publisher<nav_msgs::msg::Path>("~/path",1);
            
            exploration_timer_ = this->create_wall_timer(
    7s, std::bind(&OccupancyGridPlanner::explorationStep, this));

            if (!headless_) {
                cv::namedWindow( "OccGrid", cv::WINDOW_AUTOSIZE );
                timer_ = this->create_wall_timer( 50ms,
                        std::bind(&OccupancyGridPlanner::timer_cb, this));
            }
        }

        void timer_cb() {
            cv::waitKey(5);
        }
};

int main(int argc, char * argv[]) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<OccupancyGridPlanner>());
    rclcpp::shutdown();
}