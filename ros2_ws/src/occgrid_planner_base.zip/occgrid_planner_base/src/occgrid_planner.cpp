#include <vector>
#include <string>
#include <map>
#include <list>
#include <chrono>
#include <functional>
#include <cmath>

#include <rclcpp/rclcpp.hpp>
#include <tf2/utils.h>
#include <tf2_ros/transform_listener.h>
#include <tf2_ros/buffer.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>

#include <nav_msgs/msg/occupancy_grid.hpp>
#include <nav_msgs/msg/path.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>

#define FREE 0xFF
#define UNKNOWN 0x80
#define OCCUPIED 0x00
#define WIN_SIZE 800
#define ANGLES 8 

using std::placeholders::_1;
using namespace std::chrono_literals;

class OccupancyGridPlanner : public rclcpp::Node {
    protected:
        rclcpp::Subscription<nav_msgs::msg::OccupancyGrid>::SharedPtr og_sub_;
        rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr target_sub_;
        rclcpp::Publisher<nav_msgs::msg::Path>::SharedPtr path_pub_;
        rclcpp::TimerBase::SharedPtr timer_;

        std::shared_ptr<tf2_ros::TransformListener> tf_listener{nullptr};
        std::unique_ptr<tf2_ros::Buffer> tf_buffer;

        cv::Rect roi_;
        cv::Mat_<uint8_t> og_, cropped_og_;
        cv::Mat_<cv::Vec3b> og_rgb_, og_rgb_marked_;
        cv::Point og_center_;
        nav_msgs::msg::MapMetaData info_;
        std::string frame_id_;
        std::string base_link_;
        bool headless_;
        bool ready_;
        bool debug_;
        double robot_radius_;

        typedef std::multimap<float, cv::Point3i> Heap;

        double angles_normalize(double angle) {
            return std::atan2(std::sin(angle), std::cos(angle));
        }

        void og_callback(nav_msgs::msg::OccupancyGrid::SharedPtr msg) {
            info_ = msg->info;
            frame_id_ = msg->header.frame_id;
            og_ = cv::Mat_<uint8_t>(msg->info.height, msg->info.width, 0xFF);
            og_center_ = cv::Point(-info_.origin.position.x/info_.resolution,
                    -info_.origin.position.y/info_.resolution);

            unsigned int maxx=0, minx=msg->info.width, maxy=0, miny=msg->info.height;
            for (unsigned int j=0;j<msg->info.height;j++) {
                for (unsigned int i=0;i<msg->info.width;i++) {
                    int8_t v = msg->data[j*msg->info.width + i];
                    switch (v) {
                        case 0: og_(j,i) = FREE; break;
                        case 100: og_(j,i) = OCCUPIED; break;
                        default: og_(j,i) = UNKNOWN; break;
                    }
                    if (og_(j,i) != UNKNOWN) {
                        minx = std::min(minx,i); miny = std::min(miny,j);
                        maxx = std::max(maxx,i); maxy = std::max(maxy,j);
                    }
                }
            }

            int radius_px = std::ceil(robot_radius_ / info_.resolution);
            if (radius_px > 0) {
                cv::Mat element = cv::getStructuringElement(cv::MORPH_ELLIPSE,
                                    cv::Size(2 * radius_px + 1, 2 * radius_px + 1),
                                    cv::Point(radius_px, radius_px));
                cv::erode(og_, og_, element);
            }

            if (!ready_) {
                ready_ = true;
                RCLCPP_INFO(this->get_logger(),"Received occupancy grid, ready to plan");
            }

            unsigned int w = maxx - minx;
            unsigned int h = maxy - miny;
            roi_ = cv::Rect(minx,miny,w,h);
            if (!headless_) {
                cv::cvtColor(og_, og_rgb_, cv::COLOR_GRAY2RGB);
                cropped_og_ = cv::Mat_<uint8_t>(og_,roi_);
                if ((w > WIN_SIZE) || (h > WIN_SIZE)) {
                    double ratio = w / ((double)h);
                    cv::Size new_size = (ratio >= 1) ? cv::Size(WIN_SIZE,WIN_SIZE/ratio) : cv::Size(WIN_SIZE*ratio,WIN_SIZE);
                    cv::Mat_<uint8_t> resized_og;
                    cv::resize(cropped_og_,resized_og,new_size);
                    cv::imshow( "OccGrid", resized_og );
                } else {
                    cv::imshow( "OccGrid", og_rgb_ );
                }
            }
        }

        bool isInGrid(const cv::Point3i & P) {
            if ((P.x < 0) || (P.x >= (signed)info_.width) 
                    || (P.y < 0) || (P.y >= (signed)info_.height)) {
                return false;
            }
            return true;
        }

        void target_callback(geometry_msgs::msg::PoseStamped::SharedPtr msg) {
            geometry_msgs::msg::TransformStamped transformStamped;
            geometry_msgs::msg::PoseStamped pose;
            if (!ready_) {
                RCLCPP_WARN(this->get_logger(),"Ignoring target while grid not ready");
                return;
            }

            og_rgb_marked_ = og_rgb_.clone();
            if (debug_) {
                pose = *msg;
            } else {
                try {
                    std::string errStr;
                    tf2::TimePoint target_time = tf2_ros::fromMsg(msg->header.stamp);

                    if (!tf_buffer->canTransform(frame_id_, msg->header.frame_id, target_time,
                                tf2::durationFromSec(1.0), &errStr)) {
                        RCLCPP_ERROR(this->get_logger(),"Target transform failed: %s", errStr.c_str());
                        return;
                    }
                    transformStamped = tf_buffer->lookupTransform(frame_id_, msg->header.frame_id, target_time);
                    tf2::doTransform(*msg, pose, transformStamped);

                    if (!tf_buffer->canTransform(frame_id_, base_link_, tf2::TimePointZero,
                                tf2::durationFromSec(1.0), &errStr)) {
                        RCLCPP_ERROR(this->get_logger(),"Base transform failed: %s", errStr.c_str());
                        return;
                    }
                    transformStamped = tf_buffer->lookupTransform(frame_id_, base_link_, tf2::TimePointZero);
                }
                catch (const tf2::TransformException & ex){
                    RCLCPP_ERROR(this->get_logger(),"%s", ex.what());
                    return;
                }
            }

            double t_yaw = tf2::getYaw(pose.pose.orientation);
            double norm_t_yaw = angles_normalize(t_yaw);
            if (norm_t_yaw < 0) norm_t_yaw += 2.0 * M_PI; 
            int target_z = static_cast<int>(std::round(norm_t_yaw * ANGLES / (2.0 * M_PI))) % ANGLES;
            
            cv::Point3i target(
                (pose.pose.position.x / info_.resolution) + og_center_.x,
                (pose.pose.position.y / info_.resolution) + og_center_.y,
                target_z
            );

            cv::circle(og_rgb_marked_, cv::Point(target.x, target.y), 10, cv::Scalar(0,0,255));

            if (!isInGrid(target) || og_(target.y, target.x) != FREE) {
                RCLCPP_ERROR(this->get_logger(),"Invalid target (Out of grid or occupied)");
                return;
            }

            cv::Point3i start;
            if (debug_) {
                start = cv::Point3i(og_center_.x, og_center_.y, 0);
            } else {
                double s_yaw = tf2::getYaw(transformStamped.transform.rotation);
                double norm_s_yaw = angles_normalize(s_yaw);
                if (norm_s_yaw < 0) norm_s_yaw += 2.0 * M_PI;
                int start_z = static_cast<int>(std::round(norm_s_yaw * ANGLES / (2.0 * M_PI))) % ANGLES;
                start = cv::Point3i(
                    (transformStamped.transform.translation.x / info_.resolution) + og_center_.x,
                    (transformStamped.transform.translation.y / info_.resolution) + og_center_.y,
                    start_z
                );
            }

            cv::circle(og_rgb_marked_, cv::Point(start.x, start.y), 10, cv::Scalar(0,255,0));
            if (!headless_) cv::imshow( "OccGrid", og_rgb_marked_ );

            if (!isInGrid(start) || og_(start.y, start.x) != FREE) {
                RCLCPP_ERROR(this->get_logger(),"Invalid start (Out of grid or occupied)");
                return;
            }

            planToPixelTarget(start, target);
        }

        void planToPixelTarget(cv::Point3i start, cv::Point3i target) {
            int dims[3] = { (int)info_.height, (int)info_.width, ANGLES };
            cv::Mat_<float> cell_value(3, dims, NAN);
            cv::Mat_<cv::Vec3s> predecessor(3, dims);
            
            std::vector<cv::Point3i> neighbours = {
                cv::Point3i(1,0,0), cv::Point3i(1,1,0), cv::Point3i(0,1,0), cv::Point3i(-1,1,0),
                cv::Point3i(-1,0,0), cv::Point3i(-1,-1,0), cv::Point3i(0,-1,0), cv::Point3i(1,-1,0),
                cv::Point3i(0,0,1), cv::Point3i(0,0,-1)
            };

            auto get_heuristic = [](cv::Point3i p1, cv::Point3i p2) {
                return std::sqrt(std::pow(p1.x - p2.x, 2) + std::pow(p1.y - p2.y, 2));
            };

            Heap heap;
            heap.insert(Heap::value_type(get_heuristic(start, target), start));
            cell_value(start.y, start.x, start.z) = 0;

            bool found = false;
            while (!heap.empty()) {
                auto hit = heap.begin();
                cv::Point3i this_cell = hit->second;
                heap.erase(hit);

                if (this_cell.x == target.x && this_cell.y == target.y && this_cell.z == target.z) {
                    found = true;
                    break;
                }

                float this_g = cell_value(this_cell.y, this_cell.x, this_cell.z);

                for (int i=0; i<10; i++) {
                    cv::Point3i dest;
                    float move_cost = 0;

                    if (i < 8) { 
                        dest = cv::Point3i(this_cell.x + neighbours[i].x, this_cell.y + neighbours[i].y, this_cell.z);
                        move_cost = (std::abs(neighbours[i].x) + std::abs(neighbours[i].y) > 1) ? std::sqrt(2) : 1.0;
                    } else { 
                        dest = cv::Point3i(this_cell.x, this_cell.y, (this_cell.z + neighbours[i].z + ANGLES) % ANGLES);
                        move_cost = 0.5; 
                    }

                    if (!isInGrid(dest) || og_(dest.y, dest.x) != FREE) continue;

                    float old_g = cell_value(dest.y, dest.x, dest.z);
                    float new_g = this_g + move_cost;

                    if (std::isnan(old_g) || new_g < old_g) {
                        cell_value(dest.y, dest.x, dest.z) = new_g;
                        predecessor(dest.y, dest.x, dest.z) = cv::Vec3s(this_cell.x, this_cell.y, this_cell.z);
                        heap.insert(Heap::value_type(new_g + get_heuristic(dest, target), dest));
                    }
                }
            }

            if (!found) {
                RCLCPP_ERROR(this->get_logger(),"No path found in SE(2)");
                return;
            }

            std::list<cv::Point3i> lpath;
            cv::Point3i curr = target;
            while (curr.x != start.x || curr.y != start.y || curr.z != start.z) {
                lpath.push_front(curr);
                cv::Vec3s p = predecessor(curr.y, curr.x, curr.z);
                curr = cv::Point3i(p[0], p[1], p[2]);
            }
            lpath.push_front(start);

            nav_msgs::msg::Path path;
            path.header.stamp = this->get_clock()->now();
            path.header.frame_id = frame_id_;
            path.poses.resize(lpath.size());
            auto it = lpath.begin();
            for (unsigned int i=0; i < lpath.size(); ++i, ++it) {
                path.poses[i].header = path.header;
                path.poses[i].pose.position.x = (it->x - og_center_.x) * info_.resolution;
                path.poses[i].pose.position.y = (it->y - og_center_.y) * info_.resolution;

                double yaw = angles_normalize(it->z * (2.0 * M_PI / ANGLES));
                tf2::Quaternion q;
                q.setRPY(0, 0, yaw);
                path.poses[i].pose.orientation = tf2::toMsg(q);
            }
            path_pub_->publish(path);
        }

    public:
        OccupancyGridPlanner() : rclcpp::Node("occgrid_planner") {
            ready_ = false;
            this->declare_parameter("base_frame", std::string("bubbleRob"));
            this->declare_parameter("debug", false);
            this->declare_parameter("headless", true);
            this->declare_parameter("robot_radius", 0.2);
            
            base_link_ = this->get_parameter("base_frame").as_string();
            debug_ = this->get_parameter("debug").as_bool();
            headless_ = this->get_parameter("headless").as_bool();
            robot_radius_ = this->get_parameter("robot_radius").as_double();
            
            tf_buffer = std::make_unique<tf2_ros::Buffer>(this->get_clock());
            tf_listener = std::make_shared<tf2_ros::TransformListener>(*tf_buffer);
            
            og_sub_ = this->create_subscription<nav_msgs::msg::OccupancyGrid>("~/occ_grid", 1, std::bind(&OccupancyGridPlanner::og_callback,this,_1));
            target_sub_ = this->create_subscription<geometry_msgs::msg::PoseStamped>("~/goal", 1, std::bind(&OccupancyGridPlanner::target_callback,this,_1));
            path_pub_ = this->create_publisher<nav_msgs::msg::Path>("~/path", 1);
            
            if (!headless_) {
                cv::namedWindow( "OccGrid", cv::WINDOW_AUTOSIZE );
                timer_ = this->create_wall_timer( 50ms, [this](){ cv::waitKey(5); });
            }
        }
};

int main(int argc, char * argv[]) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<OccupancyGridPlanner>());
    rclcpp::shutdown();
    return 0;
}